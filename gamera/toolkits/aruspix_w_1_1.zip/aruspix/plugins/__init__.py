# You need to have some sort of __init__.py file here
# in order to import modules in this directory.
# It is deliberately empty.

import aruspix_plugin
